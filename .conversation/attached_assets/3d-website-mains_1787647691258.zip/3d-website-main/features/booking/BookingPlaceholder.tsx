'use client'

import { useSearchParams } from 'next/navigation'
import { motion } from 'framer-motion'
import { CalendarCheck, MessageCircle, Phone, ArrowLeft } from 'lucide-react'
import Link from 'next/link'
import { businessSettings } from '@/lib/data'
import { buildWhatsAppUrl } from '@/utils/booking'
import { SectionFlourish } from '@/components/ui/SectionFlourish'

// ─── Booking Placeholder ───────────────────────────────────────────────────────
// This page is a seam for Part 2.
// It reads the prefill context from URL query params (eventType, packageId,
// portfolioItemId, style, sourceName) so Part 2 can consume them directly
// in the multi-step booking wizard without changing the URL structure.

const eventTypeLabels: Record<string, string> = {
  wedding: 'वेडिंग डेकोरेशन',
  birthday: 'बर्थडे डेकोरेशन',
  haldi: 'हल्दी डेकोरेशन',
  mehendi: 'मेहंदी डेकोरेशन',
  stage: 'स्टेज डेकोरेशन',
  car: 'कार डेकोरेशन',
  anniversary: 'एनिवर्सरी डेकोरेशन',
  mandap: 'मंडप डेकोरेशन',
  home: 'होम डेकोरेशन',
  flower: 'फ्लावर डेकोरेशन',
  lighting: 'लाइटिंग डेकोरेशन',
  custom: 'कस्टम इवेंट',
}

export function BookingPlaceholder() {
  const searchParams = useSearchParams()

  // Read prefill context — Part 2 will consume these in the wizard
  const eventType = searchParams.get('eventType')
  const packageId = searchParams.get('packageId')
  const portfolioItemId = searchParams.get('portfolioItemId')
  const sourceName = searchParams.get('sourceName')

  const hasPrefill = !!(eventType || packageId || portfolioItemId)
  const prefillLabel = sourceName ?? (eventType ? eventTypeLabels[eventType] : null)

  const whatsappMessage = eventType
    ? `नमस्ते! मुझे ${eventTypeLabels[eventType] ?? eventType} बुक करनी है।${sourceName ? ` (${sourceName})` : ''}`
    : 'नमस्ते! मुझे डेकोरेशन बुकिंग के बारे में जानकारी चाहिए।'

  const whatsappUrl = buildWhatsAppUrl(businessSettings.whatsapp, whatsappMessage)

  return (
    <div className="min-h-screen bg-bg-void pt-20 flex items-center justify-center px-4">
      <div className="max-w-2xl w-full">
        <Link
          href="/"
          className="inline-flex items-center gap-2 text-text-muted hover:text-gold transition-colors mb-8 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-gold rounded"
        >
          <ArrowLeft size={16} />
          <span>होम पर वापस जाएं</span>
        </Link>

        <motion.div
          initial={{ opacity: 0, y: 24 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, ease: 'easeOut' }}
          className="bg-bg-purple border border-gold/20 rounded-3xl p-8 md:p-12 text-center"
        >
          <SectionFlourish className="mb-6" />

          {/* Prefill chip */}
          {hasPrefill && prefillLabel && (
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-gold/10 border border-gold/30 text-gold text-sm mb-6 font-devanagari">
              ✨ {prefillLabel} से प्री-फिल्ड
            </div>
          )}

          <div className="w-20 h-20 rounded-full bg-gold/10 border-2 border-gold/30 flex items-center justify-center mx-auto mb-6">
            <CalendarCheck size={36} className="text-gold" />
          </div>

          <h1 className="text-3xl md:text-4xl font-bold text-champagne font-devanagari mb-4">
            बुकिंग फ्लो जल्द आ रहा है!
          </h1>

          <p className="text-text-muted font-devanagari leading-relaxed mb-4 text-lg">
            हमारा ऑनलाइन बुकिंग सिस्टम Part 2 में आएगा — जिसमें होगा:
          </p>

          <ul className="text-left space-y-2 mb-8 max-w-sm mx-auto">
            {[
              'इवेंट टाइप और तारीख चुनें',
              'लाइव अवेलेबिलिटी चेक करें',
              'बजट और स्टाइल सेलेक्ट करें',
              'कस्टम कोटेशन पाएं',
              'ऑनलाइन एडवांस पेमेंट करें',
              'बुकिंग स्टेटस ट्रैक करें',
            ].map((item) => (
              <li key={item} className="flex items-center gap-2 text-text-muted text-sm font-devanagari">
                <span className="w-1.5 h-1.5 rounded-full bg-gold flex-shrink-0" />
                {item}
              </li>
            ))}
          </ul>

          <p className="text-champagne font-devanagari font-semibold mb-6">
            अभी के लिए — WhatsApp या कॉल से बुकिंग करें:
          </p>

          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <a
              href={whatsappUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center justify-center gap-2 px-8 py-4 rounded-xl bg-[#25D366] text-white font-semibold hover:bg-[#20BA5A] transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#25D366] font-devanagari"
            >
              <MessageCircle size={20} />
              WhatsApp पर बुकिंग करें
            </a>
            <a
              href={`tel:${businessSettings.phone}`}
              className="inline-flex items-center justify-center gap-2 px-8 py-4 rounded-xl bg-gold text-bg-void font-semibold hover:bg-gold-light transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-gold"
            >
              <Phone size={20} />
              {businessSettings.phone}
            </a>
          </div>

          {/* Debug info for development — shows prefill context */}
          {process.env.NODE_ENV === 'development' && hasPrefill && (
            <div className="mt-8 p-4 bg-bg-void rounded-xl border border-gold/10 text-left">
              <p className="text-gold text-xs font-mono mb-2">// Part 2 prefill context (dev only):</p>
              <pre className="text-text-muted text-xs font-mono overflow-auto">
                {JSON.stringify({ eventType, packageId, portfolioItemId, sourceName }, null, 2)}
              </pre>
            </div>
          )}
        </motion.div>
      </div>
    </div>
  )
}
